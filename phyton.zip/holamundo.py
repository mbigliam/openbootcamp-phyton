nombre="hola mundo"
print(nombre)
